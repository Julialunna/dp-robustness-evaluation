# Adaptação: DP-CVAE local + classificador federado em embeddings

Esta versão implementa a arquitetura discutida:

```text
MNIST local do cliente
→ MLP extratora de embeddings congelada
→ embeddings reais locais
→ CVAE local treinado com DP-SGD
→ embeddings sintéticos locais
→ classificador federado treinado com Flower/FedAvg nos embeddings sintéticos
```

## Ideia principal

- O **CVAE não é federado**.
- Cada cliente treina seu próprio **DP-CVAE local**.
- O servidor **não recebe pesos do CVAE** e **não recebe embeddings reais**.
- O Flower/FedAvg agrega somente o **classificador downstream** treinado em embeddings sintéticos.

## Arquivos alterados/adicionados

- `dp_cvae.py`: novo arquivo com o `ConditionalVAE`, treino local com Opacus e geração de embeddings sintéticos.
- `client.py`: agora extrai embeddings, treina/carrega CVAE local, gera embeddings sintéticos e treina o classificador federado.
- `train.py`: adiciona `EmbeddingMLP`, `EmbeddingClassifier` e funções de treino/teste em embeddings.
- `server.py`: avalia o classificador global em embeddings extraídos do MNIST test central.
- `parameters_federated.py`: adiciona parâmetros do CVAE local, embedding MLP e corrige `TARGET_EPSILON`.

Os arquivos originais foram preservados como `*_original.py`.

## Observações de privacidade

A privacidade diferencial é aplicada no **treinamento local do CVAE** via Opacus.

Por padrão, a MLP extratora de embeddings é uma MLP congelada e determinística com seed fixa. Para uma garantia formal mais forte, substitua esse extrator por um modelo público, treinado fora dos dados privados, ou treinado também com DP.

## Como rodar

```bash
pip install -r requirements.txt
python main.py
```

Na primeira rodada, cada cliente treina seu CVAE local e salva os embeddings sintéticos em:

```text
artifacts/synthetic_embeddings/client_<id>_synthetic.pt
```

Nas rodadas seguintes, por padrão, ele reutiliza o cache para não gastar novo orçamento de privacidade repetindo o treino do CVAE.

Para forçar o retreinamento do CVAE em todas as rodadas, altere em `parameters_federated.py`:

```python
RETRAIN_CVAE_EVERY_ROUND = True
```

Atenção: retreinar o CVAE em todas as rodadas aumenta o consumo de privacidade.

## Métricas impressas

- `global_accuracy`: acurácia global centralizada do classificador federado sobre embeddings reais do MNIST test.
- `accuracy`: acurácia agregada das avaliações locais.
- `epsilon_cvae_mean`: epsilon médio dos CVAEs locais.
- `cvae_loss_mean`: loss média dos CVAEs locais.
