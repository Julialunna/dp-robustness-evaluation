# Atualização: MLP pré-treinada em 10% público + FL nos 90% privados

Esta versão implementa a divisão discutida:

```text
MNIST train = 60.000 exemplos
├── 10% público/auxiliar: pré-treino da MLP extratora de embeddings
└── 90% privado/federado: particionado entre clientes Flower
```

O fluxo completo fica:

```text
1. main.py chama train.ensure_embedding_extractor_ready()
2. train.py separa o MNIST de treino sem sobreposição
3. 10% público treina a MLP extratora
4. o checkpoint é salvo em artifacts/mnist_mlp_extractor_public10.pt
5. os 90% restantes são divididos entre clientes IID ou Dirichlet
6. cada cliente usa a MLP congelada para extrair embeddings
7. cada cliente treina seu DP-CVAE local nesses embeddings
8. cada cliente gera embeddings sintéticos
9. o Flower/FedAvg treina apenas o classificador downstream nos sintéticos
```

## Arquivos alterados

- `parameters_federated.py`
  - adiciona `PRETRAIN_EXTRACTOR`, `PRETRAIN_RATIO`, `DATA_SPLIT_SEED`, `PRETRAIN_EPOCHS`, etc.
  - define `EMBEDDING_EXTRACTOR_PATH = "artifacts/mnist_mlp_extractor_public10.pt"`.

- `train.py`
  - adiciona a divisão 10%/90% sem sobreposição.
  - adiciona pré-treino da MLP extratora.
  - substitui o carregamento com `FederatedDataset` por particionamento manual dos 90% privados.
  - mantém particionamento `iid` ou `dirichlet`.

- `main.py`
  - chama o pré-treino/carregamento da MLP antes de iniciar a simulação Flower.

- `server.py`
  - usa `train.get_test_loader("ylecun/mnist")` para manter o mesmo pipeline de transformações.

## Parâmetros principais

Em `parameters_federated.py`:

```python
PRETRAIN_EXTRACTOR = True
PRETRAIN_RATIO = 0.10
DATA_SPLIT_SEED = 2026
PRETRAIN_BATCH_SIZE = 256
PRETRAIN_EPOCHS = 8
PRETRAIN_LR = 1e-3
PRETRAIN_WEIGHT_DECAY = 1e-4
FORCE_RETRAIN_EXTRACTOR = False
EMBEDDING_EXTRACTOR_PATH = "artifacts/mnist_mlp_extractor_public10.pt"
```

Se `FORCE_RETRAIN_EXTRACTOR = False` e o arquivo do extrator já existir, o pré-treino é pulado.
Para retreinar do zero, use:

```python
FORCE_RETRAIN_EXTRACTOR = True
```

## Privacidade

A privacidade diferencial do experimento cobre os 90% privados/federados usados pelos clientes.
Os 10% usados para pré-treinar a MLP devem ser tratados como conjunto público/auxiliar. Eles não são incluídos nos clientes.

## Como rodar

```bash
pip install -r requirements.txt
python main.py
```

Na primeira execução, o código deve imprimir algo como:

```text
[Dados] MNIST train dividido sem sobreposição: 6000 públicos/pretrain (10%) + 54000 privados/federados.
[Pretrain] Treinando MLP extratora com 6000 exemplos públicos por 8 épocas...
[Pretrain] Extrator salvo em artifacts/mnist_mlp_extractor_public10.pt
```

Depois disso, a simulação Flower começa normalmente.
