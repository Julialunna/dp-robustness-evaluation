# Correção: cache antigo de embeddings sintéticos

O resultado anterior ficou próximo do aleatório porque o código carregou arquivos antigos de `artifacts/synthetic_embeddings/` em vez de regenerar os sintéticos com a MLP extratora recém-treinada nos 10% públicos.

Nesta versão:

- `client.py` valida metadados do cache antes de carregar sintéticos.
- Caches antigos ou incompatíveis são ignorados e regenerados.
- `parameters_federated.py` passa a usar `SYNTHETIC_LABEL_MODE = "real_distribution"`, que é mais adequado para Dirichlet/não-IID do que gerar classes uniformes que o cliente talvez quase não tenha visto.
- Foi adicionado `SYNTHETIC_CACHE_VERSION = 2`.
- Foi adicionado `FORCE_REGENERATE_SYNTHETICS = False`.

## Para rodar uma vez de forma limpa

Antes de rodar novamente, você pode apagar manualmente os caches antigos:

```bash
rm -rf artifacts/synthetic_embeddings
python main.py
```

Ou, no Windows PowerShell:

```powershell
Remove-Item -Recurse -Force artifacts/synthetic_embeddings
python main.py
```

Depois da primeira execução corrigida, os caches novos serão reutilizados se os metadados continuarem compatíveis.
